<div id="item-display-wrap">

    <div class="items">
        <img alt="Image did not load" src=""/>
        <div class = "item-names">Item Name</div>
    </div>

    <div class="items">
        <img alt="Image did not load" src=""/>
        <div class = "item-names">Item Name 2</div>
    </div>

    <div class="items">
        <img alt="Image did not load" src=""/>
        <div class = "item-names">Item Name 3</div>
    </div>

    <div class="items">
        <img alt="Image did not load" src=""/>
        <div class = "item-names">Item Name 4</div>
    </div>


</div>