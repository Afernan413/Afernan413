<?php

$conn = mysqli_connect("localhost","root","","mjsoles_inventory");
mysqli_select_db($conn,'mjsoles_inventory');

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name ="viewport" content="width=device-width, initial-scale=1.0">
    <title>MJSOLES</title>
    <link rel="icon" href="img/Logos/smallLogo.jpeg" type="image/icon type">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>
    <link rel="stylesheet" href="style.css">

</head>

<body>
    <section id="header">
        <a href="#"><img src="img/Logos/smallLogo.jpeg" class="logo" alt =""> </a>
   
        <div>
            <ul id="navbar">
                <li><a class="active" href="home.php">Home</a></li>
                <li><a href=shop.php>Shop</a></li>
                <li><a href=about.php>About</a></li>
                <li><a href=contact.php>Contact</a></li>
                <li><a href=cart.php><i class="fas fa-shopping-cart"></i></a></li>
            </ul>
        </div>
   
   
    </section>

    <section id="hero">
        <h4>Welcome to MJSOLES</h4>
        <h2>Amazing Deals</h2>
        <h1>On New and Pre-Owned Shoes</h1>
        <h6 id="ShopLabel">Shop</h6>
        <button id = "UsedShoes">Used Shoes</button>
        <button id = "NewShoes">New Shoes</button>
        <button id = "JordanShoes">Jordan Shoes</button>
        <button id = "NikeShoes">Nike Shoes</button>
        <button id = "AdidasShoes">Adidas Shoes</button>

        <h6 id="NewArrivalLabel">New Arrivals</h6>


        <?php
        //get 10 most recent rows from databse
        $sql = "SELECT * FROM shoe_information order by date desc limit 14";
        $newarrivals = $conn->query($sql);
        while($product = mysqli_fetch_assoc($newarrivals)):
        ?>
        <section id= "NewArrivals">
            <button id = "newproduct">
            <img src=img\Product_Covers_Images\<?= $product['ID'];?>\cover.jpg alt="<?= $product['alias']; ?>"/>
            <h6><?= $product['title'];?> </h6>
            <p class="Iprice"> <?= $product['price'];?> </p>
        </button>
        </section>

        <?php endwhile; ?>
    </section>
</body>
    
</html>