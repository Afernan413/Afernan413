<?php

$conn = mysqli_connect("localhost","root","","mjsoles_inventory");
mysqli_select_db($conn,'mjsoles_inventory');

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name ="viewport" content="width=device-width, initial-scale=1.0">
    <title>MJSOLES</title>
    <link rel="icon" href="img/Logos/smallLogo.jpeg" type="image/icon type">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>
    <link rel="stylesheet" href="style.css">

</head>

<body>
    <section id="header">
        <a href="#"><img src="img/Logos/smallLogo.jpeg" class="logo" alt =""> </a>
   
        <div>
        <ul id="navbar">
                <li><a href=home.php>Home</a></li>
                <li><a href=shop.php>Shop</a></li>
                <li><a href=about.php>About</a></li>
                <li><a class="active" href="contact.php">Contact</a></li>
                <li><a href=cart.php><i class="fas fa-shopping-cart"></i></a></li>
            </ul>
        </div>
   
   
    </section>
</body>
    
</html>